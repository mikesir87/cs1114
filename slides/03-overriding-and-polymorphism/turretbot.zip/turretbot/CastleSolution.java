import sofia.micro.lightbot.*;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class CastleSolution extends Castle
{
    //~ Fields ................................................................



    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new CastleSolution object.
     */
    public CastleSolution()
    {
        // Nothing to initialize, leaving the world a default size
    }


    //~ Methods ...............................................................

    public void myProgram()
    {   
        PatrolBot patrolbot = new PatrolBot();
        this.add(patrolbot, 1, 1);
        
        PatrolBot patrolbot2 = new PatrolBot();
        this.add(patrolbot2, 7, 1);

        patrolbot.patrolCastle();
        patrolbot2.patrolCastle();
    }
}
