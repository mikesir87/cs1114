import sofia.micro.lightbot.*;

/**
 * A LightBot that knows how to patrol around a "castle" of
 * blocks.
 * 
 * The starting version here is slightly different from that
 * in the previous lecture due to the refactoring of the
 * walkOneWall method to delegate to the turnCorner method.
 * 
 * @author Michael Irwin (mikesir)
 * @version 2017.01.24
 */
public class PatrolBot extends LightBot
{

    /**
     * Create a new bot.
     */
    public PatrolBot()
    {
        // no initialization needed here
    }
    
    /**
     * Patrol around a castle.
     */
    public void patrolCastle()
    {
        this.walkOneWall();
        this.walkOneWall();
        this.walkOneWall();
        this.walkOneWall();
    }
    
    /**
     * Walk around one wall.
     */
    public void walkOneWall()
    {
        this.move();
        this.move();
        this.turnCorner();
    }
     
    /**
     * Turn around the corner.
     */
    public void turnCorner()
    {
        this.move();
        this.turnRight();
        this.move();
    }
}
