import sofia.micro.lightbot.*;

//-------------------------------------------------------------------------
/**
 *  Creates a world that contains two castles.  One castle is a
 *  standard 3x3 castle while the other has "turrets" on each
 *  corner.
 *
 *  @author Michael Irwin (mikesir)
 *  @version 2017.01.24
 */
public class Castle extends Level
{

    /**
     * Creates a new Castle object.
     */
    public Castle()
    {
        super(12, 8);
        prepare();
    }

    //~ Methods ...............................................................

    /**
     * Prepare the world for the start of the program. Creates the castles.
     */
    private void prepare()
    {
        // Castle on the left
        this.add(new Block(), 1, 2);
        this.add(new Block(), 2, 2);
        this.add(new Block(), 3, 2);
        this.add(new Block(), 3, 3);
        this.add(new Block(), 3, 4);
        this.add(new Block(), 2, 4);
        this.add(new Block(), 1, 4);
        this.add(new Block(), 1, 3);
        
        // Castle on the right
        this.add(new Block(), 7, 2);
        this.add(new Block(), 8, 2);
        this.add(new Block(), 9, 2);
        this.add(new Block(), 9, 3);
        this.add(new Block(), 9, 4);
        this.add(new Block(), 8, 4);
        this.add(new Block(), 7, 4);
        this.add(new Block(), 7, 3);

        // Top-left turret
        this.add(new Block(), 6, 1);
        
        // Top-right turret
        this.add(new Block(), 10, 1);
        
        // Bottom-left turret
        this.add(new Block(), 6, 5);

        // Bottom-right turret
        this.add(new Block(), 10, 5);
    }
}
