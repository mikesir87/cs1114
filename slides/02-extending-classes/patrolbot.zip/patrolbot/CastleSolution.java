import sofia.micro.lightbot.*;

//-------------------------------------------------------------------------
/**
 *  A scenario solution in which we start off with a LightBot that patrols
 *  around a "castle". We then learn about extending classes, where we will
 *  create and use a PatrolBot to do the actual patrolling.
 *
 *  @author Michael Irwin (mikesir)
 *  @version 2017.01.23
 */
public class CastleSolution extends Castle
{

    /**
     * Creates a new CastleSolution object.
     */
    public CastleSolution()
    {
        // Nothing to initialize, leaving the world a default size
    }

    //~ Methods ...............................................................
    /**
     * Add code to patrol around the castle below.
     */
    public void myProgram() 
    {
        LightBot bot = new LightBot();
        this.add(bot, 0, 1);

        // How can we get the LightBot to patrol around the castle?
    }
}
