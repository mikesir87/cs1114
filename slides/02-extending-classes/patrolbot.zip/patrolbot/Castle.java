import sofia.micro.lightbot.*;

//-------------------------------------------------------------------------
/**
 *  Builds a world with a "castle" in it. The castle is simply
 *  a 3x3 collection of blocks.
 *
 *  @author Michael Irwin (mikesir)
 *  @version 2017.01.23
 */
public class Castle extends Level
{

    /**
     * Creates a new Castle object.
     */
    public Castle()
    {
        prepare();
    }

    //~ Methods ...............................................................

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        this.add(new Block(), 1, 2);
        this.add(new Block(), 2, 2);
        this.add(new Block(), 3, 2);
        this.add(new Block(), 3, 3);
        this.add(new Block(), 3, 4);
        this.add(new Block(), 2, 4);
        this.add(new Block(), 1, 4);
        this.add(new Block(), 1, 3);
    }
    
}
