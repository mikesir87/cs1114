import sofia.micro.lightbot.*;

/**
 * An extension of the LightBot that has the "smarts"
 * to patrol around a 3x3 "castle".
 * 
 * @author Michael Irwin (mikesir)
 * @version 2017.01.23
 */
public class PatrolBot extends LightBot
{

    /**
     * Creates a new PatrolBot.
     */
    public PatrolBot()
    {
        // no initialization needed here
    }
    
    /**
     * Patrol around the castle.
     */
    public void patrolCastle()
    {
        // How should we make the bot patrol around the
        // entire castle?
    }
    
}
