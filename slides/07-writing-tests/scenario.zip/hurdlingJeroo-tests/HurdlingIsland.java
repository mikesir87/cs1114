import sofia.micro.jeroo.*;
import java.util.Random;

//-------------------------------------------------------------------------
/**
 * An Island that creates various "hurdles" by creating nets
 * that span from the bottom of the island straight up. The
 * columns are random, forcing the need for a smarter Jeroo
 * to detect the hurdles and get around them.
 *
 * @author Michael Irwin (mikesir)
 * @version 2017.02.08
 */
public class HurdlingIsland extends Island
{

    /**
     * Creates a new HurdlingIsland object.
     */
    public HurdlingIsland()
    {
        createHurdles();
    }


    //~ Methods ...............................................................
    
    /**
     * Creates randomly located "hurdles" with random heights.
     * Ensures that there are no two columns immediately next to
     * each other.
     */
    public void createHurdles() {
        int maxHeight = getHeight() - 3;
        Random random = new Random();
        for (int i = 2; i < getWidth() - 2; i++) {
            if (random.nextBoolean()) {
                int height = random.nextInt(maxHeight) + 1;
                for (int j = 0; j < height; j++) {
                    add(new Net(), i, getHeight() - 2 - j);
                }
                i++;
            }
        }
    }
    
    /**
     * Main program method that simply asks a Jeroo to hop.
     */
    public void myProgram() 
    {
        Jeroo jerry = new HurdlingJeroo();
        add(jerry, 1, getHeight() - 2);
        
        while (!jerry.seesWater(AHEAD))
        {
            jerry.hop();
        }
    }

}
