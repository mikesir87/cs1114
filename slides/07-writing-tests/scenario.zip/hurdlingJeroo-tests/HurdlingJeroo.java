import sofia.micro.jeroo.*;

/**
 *  An extension of a Jeroo that should be smart enough to hop
 *  "over" hurdles on an island.
 *
 *  @author Michael Irwin (mikesir)
 *  @version 2017.02.08
 */
public class HurdlingJeroo extends Jeroo
{

    /**
     * Overriding the hop method to be smart enough to avoid
     * hurdles.
     */
    public void hop()
    {
        if (seesNet(AHEAD))
        {
            hopOverHurdle();
        }
        else {
            super.hop();
        }
    }
    
    /**
     * Hops over a hurdle of nets. Is assuming that the Jeroo
     * is looking directly at the hurdle.
     */
    public void hopOverHurdle()
    {
        turn(LEFT);
        goUpHurdle();
        turnCorner();
        goDownHurdle();
        turn(LEFT);
    }
    
    /**
     * Travels up the hurdle.
     */
    public void goUpHurdle()
    {
        while (seesNet(RIGHT)) 
        {
            hop();
        }
    }
    
    /**
     * Gets over the top of the hurdle.
     */
    public void turnCorner() 
    {
        turn(RIGHT);
        hop(2);
        turn(RIGHT);
    }
    
    /**
     * Travel down the hurdle back to the water
     * below.
     */
    public void goDownHurdle()
    {
        while (!seesWater(AHEAD))
        {
            hop();
        }
    }
}
