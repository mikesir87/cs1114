import sofia.micro.*;
import java.util.List;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class Idioms extends Actor
{
    //~ Fields ................................................................



    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Idioms object.
     */
    public Idioms()
    {
        /*# Do any work to initialize your class here. */
    }

    /**
     * Calculate the sum of one to n.
     * @param n The max value to include in the sum.
     * @return The sum of 1 to n, inclusive.
     */
    public int sumOneToN(int n) {
        return 0;
    }

    
    
    /**
     * Find the first occurrence of the needle within the haystack.
     * @param haystack Collection of all string to search through
     * @param needle The search pattern to find a match for.
     * @return The first occurrence matching the substring, if one exists.
     * Otherwise, null.
     */
    public String findFirstOccurrence(List<String> haystack, String needle) {
        return null;
    }

    
    
    /**
     * Find the last occurrence of the needle within the haystack.
     * @param haystack Collection of all string to search through
     * @param needle The search pattern to find a match for.
     * @return The last occurrence matching the substring, if one exists.
     * Otherwise, null.
     */
    public String findLastOccurrence(List<String> haystack, String needle) {
        return null;
    }
    
    
    
    /**
     * Find the largest number in the provided list.
     * @param numbers The numbers to search through
     * @return The largest number. If list is empty, -1.
     */
    public int findLargest(List<Integer> numbers) {
        return -1;
    }
        
    
    
    
    /**
     * Finds the average of the provided list.
     * @param numbers The numbers to use to calculate an average.
     * @return The average. If list is empty, returns 0.
     */
    public int findAverage(List<Integer> numbers) {
        return 0;
    }
}
