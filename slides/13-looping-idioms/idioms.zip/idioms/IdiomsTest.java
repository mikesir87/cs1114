import sofia.micro.*;
import java.util.List;
import java.util.Arrays;

// -------------------------------------------------------------------------
/**
 *  Test case for the Idioms class
 *
 *  @author Michael Irwin (mikesir)
 *  @version 2017.03.14
 */
public class IdiomsTest extends TestCase
{
    private Idioms idioms;

    /**
     * Setup each test case by creating a new Idioms object.
     */
    public void setUp()
    {
        idioms = new Idioms();
    }

    /**
     * Validate the sumOneToN method.
     */
    public void testSumOneToN() {
        assertEquals(15, idioms.sumOneToN(5));
        assertEquals(28, idioms.sumOneToN(57));
    }

    /**
     * Validate the findFirstOccurrence method.
     */
    public void testFindFirstOccurrence() {
        List<String> names = Arrays.asList("Virginia Tech", "UVA", "Duke");
        assertEquals("Duke", idioms.findFirstOccurrence(names, "uk"));
        assertEquals("Virginia Tech", idioms.findFirstOccurrence(names, "e"));
        assertNull(idioms.findFirstOccurrence(names, "zz"));
    }

    /**
     * Validate the findLastOccurrence method.
     */
    public void testFindLastOccurrence() {
        List<String> names = Arrays.asList("Virginia Tech", 
                "University of Virginia", 
                "Virginia Commonwealth University");

        assertEquals("Virginia Commonwealth University", 
            idioms.findLastOccurrence(names, "Virginia"));
        assertEquals("Virginia Tech", 
            idioms.findLastOccurrence(names, "T"));
        assertNull(idioms.findLastOccurrence(names, "zz"));
    }
    
    /**
     * Validate the findLargest method.
     */
    public void testFindLargest() {
        assertEquals(9, idioms.findLargest(Arrays.asList(2, 7, 3, 9, 1)));
        assertEquals(9, idioms.findLargest(Arrays.asList(9, 2, 7, 3, 1)));
        assertEquals(9, idioms.findLargest(Arrays.asList(2, 7, 3, 1, 9)));
    }
    
    /**
     * Validate the findAverage method.
     */
    public void testFindAverage() {
        assertEquals(4, idioms.findAverage(Arrays.asList(2, 7, 3, 7, 1)));
    }
}
