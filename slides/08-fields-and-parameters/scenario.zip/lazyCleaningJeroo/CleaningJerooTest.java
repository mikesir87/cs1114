import sofia.micro.*;
import sofia.micro.jeroo.*;
import static sofia.micro.jeroo.CompassDirection.*;
import static sofia.micro.jeroo.RelativeDirection.*;

// -------------------------------------------------------------------------
/**
 * Unit tests for the CleaningJeroo class.
 *
 * @author Michael Irwin (mikesir)
 * @version 2017.02.13
 */
public class CleaningJerooTest extends TestCase
{

    /**
     * Sets up the test fixture.
     * Called before every test case method.
     */
    public void setUp()
    {
        /*# Insert your own setup code here */
    }

    /**
     * Test the cleanUpTheIsland method by placing flowers on the starting
     * and ending location and a few other random locations. Then,
     * validate that they're all gone and the CleaningJeroo is at the
     * correct final location.
     */
    public void testCleanUpTheIsland()
    {
        Island island = new Island();
        CleaningJeroo cleaner = new CleaningJeroo();
        island.add(cleaner, 1, 1);
        
        // Place a flower on the starting location
        island.add(new Flower(), 1, 1);
        
        // Place a flower on the ending location
        island.add(new Flower(), 1, 10);
        
        // Other "random flowers"
        island.add(new Flower(), 4, 4);
        island.add(new Flower(), 6, 1);
        island.add(new Flower(), 8, 10);
        
        cleaner.cleanUpTheIsland();
        
        assertEquals(1, cleaner.getGridX());
        assertEquals(10, cleaner.getGridY());
        assertTrue(island.getObjects(Flower.class).isEmpty());
    }

    /**
     * Tests cleanRow method by placing flowers in two rows and validating
     * only the first row's flowers are gone.
     */
    public void testCleanRow()
    {
        Island island = new Island();
        CleaningJeroo cleaner = new CleaningJeroo();
        island.add(cleaner, 1, 1);

        // First row flowers
        island.add(new Flower(), 1, 1);
        island.add(new Flower(), 3, 1);
        island.add(new Flower(), 5, 1);
        
        // Place a flower on the next row
        island.add(new Flower(), 1, 2);
        
        cleaner.cleanRow();
        
        assertEquals(10, cleaner.getGridX());
        assertEquals(1, cleaner.getGridY());
        assertEquals(1, island.getObjects(Flower.class).size());
        
        // Validate that the remaining flower is on the second row
        // We'll talk more about lists and accessing elements later...
        assertEquals(2, island.getObjects(Flower.class).get(0).getGridY());
    }

    /**
     * Validate that when the jeroo is facing east and turns the corner,
     * he ends up facing west on the next row.
     */
    public void testTurnCornerWhenFacingEast()
    {
        Island island = new Island();
        CleaningJeroo cleaner = new CleaningJeroo();
        island.add(cleaner, 10, 1);
        
        cleaner.turnCorner();
        
        assertTrue(cleaner.isFacing(WEST));
        assertEquals(10, cleaner.getGridX());
        assertEquals(2, cleaner.getGridY());
    }
    

    /**
     * Validate that when the jeroo is facing west and turns the corner,
     * he ends up facing east on the next row.
     */
    public void testTurnCornerWhenFacingWest()
    {
        Island island = new Island();
        CleaningJeroo cleaner = new CleaningJeroo();
        island.add(cleaner, 1, 1);
        cleaner.turn(RIGHT);
        cleaner.turn(RIGHT);
        
        cleaner.turnCorner();
        
        assertTrue(cleaner.isFacing(EAST));
        assertEquals(1, cleaner.getGridX());
        assertEquals(2, cleaner.getGridY());
    }
    
    /**
     * Validate that when the jeroo hops, he removes a flower
     * if it's present.
     */
    public void testOverriddenHop()
    {
        Island island = new Island();
        CleaningJeroo cleaner = new CleaningJeroo();
        island.add(cleaner, 1, 1);
        island.add(new Flower(), 1, 1);
        
        cleaner.hop();
        
        assertEquals(2, cleaner.getGridX());
        assertTrue(island.getObjects(Flower.class).isEmpty());
    }
    
    /**
     * Verify the checkForFlower method by validating a flower is removed
     * if present.
     */
    public void testCheckForFlower()
    {
        Island island = new Island();
        CleaningJeroo cleaner = new CleaningJeroo();
        island.add(cleaner, 1, 1);
        island.add(new Flower(), 1, 1);
        
        cleaner.checkForFlower();
        
        assertTrue(island.getObjects(Flower.class).isEmpty());
    }
    
}
