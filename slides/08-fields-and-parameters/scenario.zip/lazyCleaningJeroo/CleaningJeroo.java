import sofia.micro.jeroo.*;

//-------------------------------------------------------------------------
/**
 * A Jeroo that is smart enough to remove all flowers from the world.
 *
 * @author Michael Irwin (mikesir)
 * @version 2017.02.13
 */
public class CleaningJeroo extends Jeroo
{

    /**
     * Clean the island of all flowers. Navigates back and forth
     * along each row to collect all flowers.
     */
    public void cleanUpTheIsland() 
    {
        int lastRowY = getWorld().getHeight() - 2;
        while (getGridY() != lastRowY)
        {
            cleanRow();
            turnCorner();
        }
        
        // While loop breaks once we get to last row, but we
        // still want to clean it.
        cleanRow();
        
        // Since we're checking for flowers before we hop, make
        // sure we check for a flower on the last spot we land on.
        checkForFlower();
    }
    
    /**
     * Clean a specific row. Simply navigates across the row, as the
     * overridden hop method checks for flowers.
     */
    public void cleanRow()
    {
        while (!seesWater(AHEAD))
        {
            hop();
        }
    }
    
    /**
     * Turns a corner by determining if it's facing east or west.
     */
    public void turnCorner()
    {
        if (isFacing(EAST))
        {
            turn(RIGHT);
            hop();
            turn(RIGHT);
        }
        else
        {
            turn(LEFT);
            hop();
            turn(LEFT);
        }
    }
    
    /**
     * Checks for the presence of a flower before hopping.
     */
    public void hop()
    {
        checkForFlower();
        super.hop();
    }
    
    /**
     * Checks for the presence of a flower and picks it if it's there.
     */
    public void checkForFlower()
    {
        if (seesFlower(HERE))
        {
            pick();
        }
    }
}
