import sofia.micro.jeroo.*;

//-------------------------------------------------------------------------
/**
 * A Jeroo that is capable of patrolling around a "castle".
 *
 * @author Michael Irwin (mikesir)
 * @version 2017.01.30
 */
public class PatrolJeroo extends Jeroo
{
    //~ Fields ................................................................



    //~ Constructor ...........................................................

    /**
     * Creates a new PatrolJeroo object.
     */
    public PatrolJeroo()
    {
        super();
    }


    //~ Methods ...............................................................

    /**
     * Patrol around the entire castle.
     */
    public void patrolCastle()
    {
        this.patrolWall();
        this.patrolWall();
        this.patrolWall();
        this.patrolWall();
    }


    /**
     * Patrol along one wall.
     */
    public void patrolWall()
    {
        this.hop();
        this.hop();
        this.turnCorner();
    }


    /**
     * Patrol around the corner.
     */
    public void turnCorner()
    {
        this.hop();
        this.turn(RIGHT);
        this.hop();
    }
}
