import sofia.micro.jeroo.*;

//-------------------------------------------------------------------------
/**
 * A smarter PatrolJeroo that knows how to turn castle
 * corners that have turrets.
 *
 * @author Michael Irwin (mikesir)
 * @version 2017.01.30
 */
public class TurretJeroo extends PatrolJeroo
{
    //~ Fields ................................................................



    //~ Constructor ...........................................................

    /**
     * Creates a new TurretJeroo object.
     */
    public TurretJeroo()
    {
        super();
    }


    //~ Methods ...............................................................

    /**
     * Patrol around a corner that has a turret.
     */
    public void turnCorner()
    {
        this.turn(LEFT);

        super.turnCorner();
        super.turnCorner();
        super.turnCorner();
        
        this.turn(LEFT);
    }
}
