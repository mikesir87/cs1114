import sofia.micro.jeroo.*;

/**
 *  An extension of a Jeroo that should be smart enough to hop
 *  "over" hurdles on an island.
 *
 *  @author Michael Irwin (mikesir)
 *  @version 2017.01.31
 */
public class HurdlingJeroo extends Jeroo
{

    /*
     * Look at the HurdlingIsland class and look to see
     * what's expected. 
     * 
     * HINT... might need to override a method.
     */
    
}
