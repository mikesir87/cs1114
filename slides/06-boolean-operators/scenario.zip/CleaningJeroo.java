import sofia.micro.jeroo.*;

//-------------------------------------------------------------------------
/**
 * A Jeroo that is smart enough to know how to clean up the
 * island from flowers.
 *
 * @author Michael Irwin (mikesir)
 * @version 2017.02.06
 */
public class CleaningJeroo extends Jeroo
{

    /**
     * Creates a new CleaningJeroo object.
     */
    public CleaningJeroo()
    {
        /*# Do any work to initialize your class here. */
    }

    public void cleanUpTheIsland()
    {
        /*
         * We need to build a while loop to get all of the flowers
         *  - How do we know we're done looping?
         *  - How do we code that condition?
         *  - How can we make progress towards the goal?
         */
    }
    
}
