import sofia.micro.jeroo.*;
import java.util.Random;

//-------------------------------------------------------------------------
/**
 * An island that is overgrown with flowers! Upon creation, the
 * island is randomly populated with flowers, meaning that the
 * layout is different every time.
 * 
 * The program creates a new CleaningJeroo, who will clean up the
 * island.
 *
 * @author Michael Irwin (mikesir)
 * @version 2017.02.06
 */
public class OvergrownIsland extends Island
{

    /**
     * Creates a new OvergrownIsland object.
     */
    public OvergrownIsland()
    {
        super(12, 12);
        prepareIsland();
    }

    /**
     * Place flowers at random locations throughout the island.
     */
    public void prepareIsland()
    {
        Random random = new Random();
        for (int i = 1; i < getHeight() - 1; i++) {
            for (int j = 1; j < getWidth() - 1; j++) {
                if (random.nextBoolean())
                    add(new Flower(), j, i);
            }
        }
    }

    /**
     * Creates a CleaningJeroo and cleans up the island.
     */
    public void myProgram() {
        CleaningJeroo jeroo = new CleaningJeroo();
        add(jeroo, 1, 1);
        jeroo.cleanUpTheIsland();
    }
}
